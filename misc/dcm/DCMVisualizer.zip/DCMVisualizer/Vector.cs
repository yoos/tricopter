﻿
namespace DCMVisualizer
{
	public class Vector
	{
		public float[] v = new float[3];

		public Vector() {;}
		public Vector(float v0, float v1, float v2)
		{
			v[0] = v0;
			v[1] = v1;
			v[2] = v2;
		}
	};
}
