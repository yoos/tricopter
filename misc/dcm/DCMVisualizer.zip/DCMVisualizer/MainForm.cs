﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Text;
using System.Windows.Forms;


namespace DCMVisualizer
{
	public partial class MainForm : Form
	{
		const float ViewDist = 8.0f;
		const float ViewScale = 400.0f;
		float DrawScale = 1.0f;

		bool Stereo = false;
		bool LocalMode = false;

		SerialPort comm = null;
		float CenterX = 0.0f;
		float CenterY = 0.0f;
		float OffsetX = 0.0f;

		int ax, ay, az;
		int gx, gy, gz;

		int SampleCount = 0;
		FixedVector avg = new FixedVector(0, 0, 0);
		FixedVector DownCorrect = new FixedVector(0, 0, 0);
		FixedVector CorrectionScaled = new FixedVector(0, 0, 0);	// Correction factor from Accelerometer

		Matrix Body = new Matrix();
		FixedMatrix BodyEst;
		FixedMatrix BodyEstCorr;

		Matrix Rot = new Matrix();
		FixedMatrix RotEst = new FixedMatrix();


		Vector[] CubePt = new Vector[8];
		FixedVector[] CubeInt = new FixedVector[8];

		int[] CubeLine;

		private bool Active = true;

		public MainForm()
		{
			InitializeComponent();

			CubePt[0] = new Vector(-1.0f, -0.25f, -1.2f);
			CubePt[1] = new Vector(-1.0f,  0.25f, -1.2f);
			CubePt[2] = new Vector( 1.0f, -0.25f, -1.2f);
			CubePt[3] = new Vector( 1.0f,  0.25f, -1.2f);
			CubePt[4] = new Vector(-1.0f, -0.25f,  1.2f);
			CubePt[5] = new Vector(-1.0f,  0.25f,  1.2f);
			CubePt[6] = new Vector( 1.0f, -0.25f,  1.2f);
			CubePt[7] = new Vector( 1.0f,  0.25f,  1.2f);

			for (int i = 0; i < 8; i++)
			{
				CubeInt[i] = new FixedVector(CubePt[i]);
			}

			CubeLine = new int[] { 0,1, 1,3, 3,2, 2,0, 4,5, 5,7, 7,6, 6,4, 0,4, 1,5, 2,6, 3,7 };

			ResetBodyMatrix();
		}

		private void ResetBodyMatrix()
		{
			Body.m[0, 0] = 1.0f; Body.m[0, 1] = 0.0f; Body.m[0, 2] = 0.0f;
			Body.m[1, 0] = 0.0f; Body.m[1, 1] = 1.0f; Body.m[1, 2] = 0.0f;
			Body.m[2, 0] = 0.0f; Body.m[2, 1] = 0.0f; Body.m[2, 2] = 1.0f;

			BodyEst = new FixedMatrix(Body);
			BodyEstCorr = new FixedMatrix(Body);
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			// Open the serial port COM8 at 115200 baud, no parity, 8 bits, one stop bit
			comm = new SerialPort("COM8", 115200, Parity.None, 8, StopBits.One);
			comm.Open();
			Active = true;

			// Start my 'tick timer' - It's set to tick every 20 milliseconds
			// (used to check the comm port periodically instead of using a thread)
			tickTimer.Start();
		}

		private void SetActive(bool NewActive)
		{
            if(Active == NewActive) return;
			if(NewActive == false)
			{
				comm.Close();
			}
			else
			{
				comm.Open();
			}

			Active = NewActive;
		}

		int GetCommWord()
		{
			int val = (short)(comm.ReadByte() << 8);
			val |= comm.ReadByte();
			return val;
		}

		// This function is called every time my timer object ticks (every 20ms)
		private void tickTimer_Tick(object sender, EventArgs e)
		{
			if (Active == false) return;

			bool GotPacket = false;
			if (LocalMode)
			{
				while (comm.BytesToRead >= 20)
				{
					// Look for the 0x7777 packet header used to denote the start of the packet
					if (comm.ReadByte() != 0x77) continue; // didn't get an 0x77, so this isn't the beginning - exit the loop
					if (comm.ReadByte() != 0x77) continue; // now check the 2nd byte too...  same as the first

					// At this point, we read two 0x77 bytes in a row, so I assume this is a 'real' packet
					// and not just noise.  Start building up my data

					gx = GetCommWord();
					gy = GetCommWord();
					gz = GetCommWord();

					ax = GetCommWord();
					ay = GetCommWord();
					az = GetCommWord();

					// Signal that we built a valid packet
					GotPacket = true;

					UpdateMatrices();
				}
			}
			else
			{
				while (comm.BytesToRead >= 11)
				{
					// Look for the 0x7878 packet header used to denote the start of the packet
					if (comm.ReadByte() != 0x78) continue; // didn't get an 0x78, so this isn't the beginning - exit the loop
					if (comm.ReadByte() != 0x78) continue; // now check the 2nd byte too...  same as the first

					// At this point, we read two 0x78 bytes in a row, so I assume this is a 'real' packet
					// and not just noise.  Start building up my data

					BodyEstCorr.m[0, 0] = (SByte)comm.ReadByte() << 9;
					BodyEstCorr.m[0, 1] = (SByte)comm.ReadByte() << 9;
					BodyEstCorr.m[0, 2] = (SByte)comm.ReadByte() << 9;

					BodyEstCorr.m[1, 0] = (SByte)comm.ReadByte() << 9;
					BodyEstCorr.m[1, 1] = (SByte)comm.ReadByte() << 9;
					BodyEstCorr.m[1, 2] = (SByte)comm.ReadByte() << 9;

					BodyEstCorr.m[2, 0] = (SByte)comm.ReadByte() << 9;
					BodyEstCorr.m[2, 1] = (SByte)comm.ReadByte() << 9;
					BodyEstCorr.m[2, 2] = (SByte)comm.ReadByte() << 9;

					// Signal that we built a valid packet
					GotPacket = true;
				}
			}

			// If we got a valid packet, mark the window as requiring a repaint
			if (GotPacket)
			{
				Invalidate();
			}
		}

		float GyroToRad(int g)
		{
			float val = (float)(g / 14.375) / (180.0f / 3.141592654f);	// Convert LSBs to degrees, then deg to radians
			val /= 200.0f ;												// Convert from "per second" to "per sample at 200hz"
			return val;
		}

		float Cos(float f)
		{
			return (float)Math.Cos((float)f);
		}

		float Sin(float f)
		{
			return (float)Math.Sin((float)f);
		}

		int GyroScale(int g)
		{
			return g * 1 / 5;
		}

		FixedVector GetAccelAsFixedVector()
		{
			return new FixedVector(ax << (FixedMatrix.Bits - 8), az << (FixedMatrix.Bits - 8), ay << (FixedMatrix.Bits - 8));
		}


		private void UpdateMatrices()
		{
			if (SampleCount < 128)
			{
				avg = avg.Add(GetAccelAsFixedVector());
				SampleCount++;

				if (SampleCount == 128)
				{
					avg.v[0] /= 128;
					avg.v[1] /= 128;
					avg.v[2] /= 128;

					DownCorrect = new FixedVector(avg.v[0], avg.v[1] - (1 << FixedMatrix.Bits), avg.v[2]);
				}
			}

			//deltaDCM = [ 1 -delta_psi, delta_theta ]
			//			[ delta_psi, 1, -delta_phi ]
			//			[ -delta_theta, delta_phi, 1 ]

			int iGz = -GyroScale(gx);
			int iGx =  GyroScale(gy);
			int iGy = -GyroScale(gz);

			RotEst.m[0, 0] = 1 << FixedMatrix.Bits;
			RotEst.m[0, 1] = -iGz;
			RotEst.m[0, 2] = iGy;

			RotEst.m[1, 0] = iGz;
			RotEst.m[1, 1] = 1 << FixedMatrix.Bits;
			RotEst.m[1, 2] = -iGx;

			RotEst.m[2, 0] = -iGy;
			RotEst.m[2, 1] = iGx;
			RotEst.m[2, 2] = 1 << FixedMatrix.Bits;

			BodyEst = BodyEst.Mul(RotEst);
			BodyEst.Renormalize();


			iGz += CorrectionScaled.v[2];
			iGx += CorrectionScaled.v[0];
			iGy += CorrectionScaled.v[1];

			RotEst.m[0, 0] = 1 << FixedMatrix.Bits;
			RotEst.m[0, 1] = -iGz;
			RotEst.m[0, 2] = iGy;

			RotEst.m[1, 0] = iGz;
			RotEst.m[1, 1] = 1 << FixedMatrix.Bits;
			RotEst.m[1, 2] = -iGx;

			RotEst.m[2, 0] = -iGy;
			RotEst.m[2, 1] = iGx;
			RotEst.m[2, 2] = 1 << FixedMatrix.Bits;

			BodyEstCorr = BodyEstCorr.Mul(RotEst);
			BodyEstCorr.Renormalize();


			// Gravity (or some approximation thereof) is the accelerometer
			FixedVector Gravity = GetAccelAsFixedVector();
			Gravity = Gravity.Subtract(DownCorrect);

			FixedVector WorldUp = new FixedVector(BodyEstCorr.m[1, 0], BodyEstCorr.m[1, 1], BodyEstCorr.m[1, 2]);

			FixedVector GravityNorm = Gravity.Normalized();
			int CorrectionScale = (1 << FixedMatrix.Bits) - WorldUp.Dot(GravityNorm) >> 6;

			FixedVector Correction = BodyEstCorr.Mul(GravityNorm);
			FixedVector ErrorAxis = GravityNorm.Cross(WorldUp);

			ErrorAxis = ErrorAxis.Scale( (1<<FixedMatrix.Bits) >> 8);

			CorrectionScaled.v[0] = ErrorAxis.v[0];
			CorrectionScaled.v[1] = ErrorAxis.v[1];
			CorrectionScaled.v[2] = ErrorAxis.v[2];
		}


		// Handle repainting the main window
		private void MainForm_Paint(object sender, PaintEventArgs e)
		{
			CenterX = (float)(ClientRectangle.Width / 2);
			CenterY = (float)(ClientRectangle.Height / 2);
			DrawScale = ViewScale * ((float)ClientRectangle.Width / 560.0f);

			float RealCenterX = CenterX;

			float[] cx = new float[2];
			cx[0] = CenterX * 2/4;
			cx[1] = CenterX + CenterX * 2/4;

			// Gravity (or some approximation thereof) is the accelerometer
			FixedVector Gravity = GetAccelAsFixedVector();
			Gravity = Gravity.Subtract(DownCorrect);

			// The 2nd column is the Y direction of the body in world space
			FixedVector BodyUp = new FixedVector(BodyEstCorr.m[0, 1], BodyEstCorr.m[1, 1], BodyEstCorr.m[2, 1]);
			FixedVector BodyLeft = new FixedVector(BodyEstCorr.m[0, 0], BodyEstCorr.m[1, 0], BodyEstCorr.m[2, 0]);
			FixedVector BodyFwd = new FixedVector(BodyEstCorr.m[0, 2], BodyEstCorr.m[1, 2], BodyEstCorr.m[2, 2]);

			FixedVector WorldLeft = new FixedVector(BodyEstCorr.m[0, 0], BodyEstCorr.m[0, 1], BodyEstCorr.m[0, 2]);
			FixedVector WorldFwd = new FixedVector(BodyEstCorr.m[2, 0], BodyEstCorr.m[2, 1], BodyEstCorr.m[2, 2]);
			FixedVector WorldUp = new FixedVector(BodyEstCorr.m[1, 0], BodyEstCorr.m[1, 1], BodyEstCorr.m[1, 2]);


			FixedVector GravityNorm = Gravity.Normalized();
			FixedVector Correction = BodyEstCorr.Mul(GravityNorm);

			if (Stereo)
			{
				for (int view = 0; view < 2; view++)
				{
					CenterX = cx[view];
					OffsetX = (-0.5f + (float)view) * -1.0f;

					if( LocalMode ) DrawCube(e.Graphics, BodyEst, Color.Green);
					DrawCube(e.Graphics, BodyEstCorr, Color.White);

					if( LocalMode ) DrawLine(e.Graphics, new FixedVector(0, 0, 0), Gravity, 2.0f, Color.BlueViolet);
					DrawLine(e.Graphics, new FixedVector(0, 0, 0), BodyUp, 1.0f, Color.Yellow);

					if( LocalMode ) DrawLine(e.Graphics, new FixedVector(0, 0, 0), WorldUp, 2.0f, Color.Aqua);
					if( LocalMode ) DrawLine(e.Graphics, new FixedVector(0, 0, 0), Correction, 2.0f, Color.Orange);

					DrawLine(e.Graphics, new FixedVector(0, 0, 0), BodyLeft, 1.0f, Color.Red);
					DrawLine(e.Graphics, new FixedVector(0, 0, 0), BodyFwd, 1.0f, Color.Green);
				}
			}
			else
			{
				OffsetX = 0.0f;

				if( LocalMode ) DrawCube(e.Graphics, BodyEst, Color.Green);
				DrawCube(e.Graphics, BodyEstCorr, Color.White);

				if( LocalMode ) DrawLine(e.Graphics, new FixedVector(0, 0, 0), Gravity, 2.0f, Color.BlueViolet);
				DrawLine(e.Graphics, new FixedVector(0, 0, 0), BodyUp, 1.0f, Color.Yellow);

				if( LocalMode ) DrawLine(e.Graphics, new FixedVector(0, 0, 0), WorldUp, 2.0f, Color.Aqua);
				if( LocalMode ) DrawLine(e.Graphics, new FixedVector(0, 0, 0), Correction, 2.0f, Color.Orange);

				DrawLine(e.Graphics, new FixedVector(0, 0, 0), BodyLeft, 1.0f, Color.Red);
				DrawLine(e.Graphics, new FixedVector(0, 0, 0), BodyFwd, 1.0f, Color.Green);
			}
		}


		void DrawCube(Graphics g, Matrix m, Color col)
		{
			Vector[] pt = new Vector[8];
			for (int i = 0; i < 8; i++)
			{
				pt[i] = m.Mul(CubePt[i]);
				pt[i].v[0] += OffsetX;
			}

			for (int i = 0; i < 8; i++)
			{
				pt[i].v[2] += ViewDist;

				pt[i].v[0] /= pt[i].v[2];
				pt[i].v[1] /= pt[i].v[2];
			}

			Pen penCol = new Pen(col);
			PointF[] cb = new PointF[2];

			for (int i = 0; i < CubeLine.Length; i += 2)
			{
				cb[0].X = pt[CubeLine[i]].v[0];
				cb[0].Y = pt[CubeLine[i]].v[1];
				cb[1].X = pt[CubeLine[i + 1]].v[0];
				cb[1].Y = pt[CubeLine[i + 1]].v[1];

				cb[0].X = cb[0].X * DrawScale + CenterX;
				cb[0].Y = cb[0].Y *-DrawScale + CenterY;
				cb[1].X = cb[1].X * DrawScale + CenterX;
				cb[1].Y = cb[1].Y *-DrawScale + CenterY;

				g.DrawLine(penCol, cb[0], cb[1]);
			}
		}

		void DrawCube(Graphics g, FixedMatrix fm, Color col)
		{
			Matrix m = new Matrix(fm);

			Vector[] pt = new Vector[8];
			for (int i = 0; i < 8; i++)
			{
				pt[i] = m.Mul(CubePt[i]);
				pt[i].v[0] += OffsetX;
			}

			for (int i = 0; i < 8; i++)
			{
				pt[i].v[2] += ViewDist;

				pt[i].v[0] /= pt[i].v[2];
				pt[i].v[1] /= pt[i].v[2];
			}

			Pen penCol = new Pen(col);
			PointF[] cb = new PointF[2];

			for (int i = 0; i < CubeLine.Length; i += 2)
			{
				cb[0].X = pt[CubeLine[i]].v[0];
				cb[0].Y = pt[CubeLine[i]].v[1];
				cb[1].X = pt[CubeLine[i + 1]].v[0];
				cb[1].Y = pt[CubeLine[i + 1]].v[1];

				cb[0].X = cb[0].X * DrawScale + CenterX;
				cb[0].Y = cb[0].Y * -DrawScale + CenterY;
				cb[1].X = cb[1].X * DrawScale + CenterX;
				cb[1].Y = cb[1].Y * -DrawScale + CenterY;

				g.DrawLine(penCol, cb[0], cb[1]);
			}
		}

		void DrawLine(Graphics g, FixedVector v1, FixedVector v2, float Scale, Color col)
		{
			Vector[] pt = new Vector[2];
			pt[0] = new Vector();
			pt[0].v[0] = (float)v1.v[0] / (float)(1 << FixedMatrix.Bits) * Scale;
			pt[0].v[1] = (float)v1.v[1] / (float)(1 << FixedMatrix.Bits) * Scale;
			pt[0].v[2] = (float)v1.v[2] / (float)(1 << FixedMatrix.Bits) * Scale;
			pt[0].v[0] += OffsetX;

			pt[1] = new Vector();
			pt[1].v[0] = (float)v2.v[0] / (float)(1 << FixedMatrix.Bits) * Scale;
			pt[1].v[1] = (float)v2.v[1] / (float)(1 << FixedMatrix.Bits) * Scale;
			pt[1].v[2] = (float)v2.v[2] / (float)(1 << FixedMatrix.Bits) * Scale;
			pt[1].v[0] += OffsetX;

			pt[0].v[2] += ViewDist;
			pt[0].v[0] /= pt[0].v[2];
			pt[0].v[1] /= pt[0].v[2];

			pt[1].v[2] += ViewDist;
			pt[1].v[0] /= pt[1].v[2];
			pt[1].v[1] /= pt[1].v[2];


			Pen penCol = new Pen(col);
			PointF[] cb = new PointF[2];

			cb[0].X = pt[0].v[0];
			cb[0].Y = pt[0].v[1];
			cb[1].X = pt[1].v[0];
			cb[1].Y = pt[1].v[1];

			cb[0].X = cb[0].X * DrawScale + CenterX;
			cb[0].Y = cb[0].Y *-DrawScale + CenterY;
			cb[1].X = cb[1].X * DrawScale + CenterX;
			cb[1].Y = cb[1].Y *-DrawScale + CenterY;

			g.DrawLine(penCol, cb[0], cb[1]);
		}

		private void MainForm_Activated(object sender, EventArgs e)
		{
			//SetActive(true);
		}

		private void MainForm_Deactivate(object sender, EventArgs e)
		{
			//SetActive(false);
		}


		private void MainForm_MouseDoubleClick(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
				ResetBodyMatrix();
			else if (e.Button == MouseButtons.Right)
				Stereo = !Stereo;

			Invalidate();
		}
	}
}
