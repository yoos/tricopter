﻿using System;

namespace DCMVisualizer
{
	public class FixedVector
	{
		public int[] v = new int[3];

		public FixedVector() { ;}
		public FixedVector(int v0, int v1, int v2)
		{
			v[0] = v0;
			v[1] = v1;
			v[2] = v2;
		}

		public FixedVector(Vector Vec)
		{
			v[0] = (int)(Vec.v[0] * (float)(1 << FixedMatrix.Bits));
			v[1] = (int)(Vec.v[1] * (float)(1 << FixedMatrix.Bits));
			v[2] = (int)(Vec.v[2] * (float)(1 << FixedMatrix.Bits));
		}

		public FixedVector Scale(int factor)
		{
			FixedVector r = new FixedVector();
			r.v[0] = (v[0] * factor) / (1<<FixedMatrix.Bits);
			r.v[1] = (v[1] * factor) / (1<<FixedMatrix.Bits);
			r.v[2] = (v[2] * factor) / (1<<FixedMatrix.Bits);
			return r;
		}

		public int Dot(FixedVector rhs)
		{
			int r = v[0] * rhs.v[0] + v[1] * rhs.v[1] + v[2] * rhs.v[2];
			r /= (1<<FixedMatrix.Bits);
			return r;
		}

		public FixedVector Normalized()
		{
			int scale = ((3 << FixedMatrix.Bits) - Dot(this)) >> 1;
			return Scale(scale);
		}

		public FixedVector Cross(FixedVector rhs)
		{
			FixedVector r = new FixedVector();
			r.v[0] = (v[1] * rhs.v[2] - v[2] * rhs.v[1]) >> FixedMatrix.Bits;
			r.v[1] = (v[2] * rhs.v[0] - v[0] * rhs.v[2]) >> FixedMatrix.Bits;
			r.v[2] = (v[0] * rhs.v[1] - v[1] * rhs.v[0]) >> FixedMatrix.Bits;
			return r;
		}

		public FixedVector Add(FixedVector rhs)
		{
			return new FixedVector(v[0] + rhs.v[0], v[1] + rhs.v[1], v[2] + rhs.v[2]);
		}

		public FixedVector Subtract(FixedVector rhs)
		{
			return new FixedVector(v[0] - rhs.v[0], v[1] - rhs.v[1], v[2] - rhs.v[2]);
		}
	};
}
