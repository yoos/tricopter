﻿
namespace DCMVisualizer
{
	public class FixedMatrix
	{
		public int[,] m = new int[3, 3];
		public const int Bits = 15;

		public FixedMatrix() {}

		public FixedMatrix(Matrix from)
		{
			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 3; j++) {
					m[i, j] = (int)(from.m[i, j] * (float)(1 << Bits));
				}
			}
		}

		public FixedMatrix(FixedMatrix from)
		{
			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 3; j++) {
					m[i, j] = from.m[i, j];
				}
			}
		}

		public FixedMatrix Mul(FixedMatrix m1)
		{
			FixedMatrix r = new FixedMatrix();
			for (int i = 0; i < 3; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					r.m[i, j] = 0;
					for (int k = 0; k < 3; k++) {
						r.m[i, j] += m[i, k] * m1.m[k, j];
					}
					r.m[i, j] /= (1 << Bits);
				}
			}
			return r;
		}

		public FixedVector Mul(FixedVector v1)
		{
			FixedVector r = new FixedVector();
			for (int i = 0; i < 3; i++)
			{
				r.v[i] = 0;
				for (int j = 0; j < 3; j++) {
					r.v[i] += m[i, j] * v1.v[j];
				}
				r.v[i] /= (1 << Bits);
			}
			return r;
		}

		public FixedVector MulTransposed(FixedVector v1)
		{
			FixedVector r = new FixedVector();
			for (int i = 0; i < 3; i++)
			{
				r.v[i] = 0;
				for (int j = 0; j < 3; j++)
				{
					r.v[i] += m[j, i] * v1.v[j];
				}
				r.v[i] /= (1 << Bits);
			}
			return r;
		}

		public void Renormalize()
		{
			FixedVector xRow = new FixedVector(m[0, 0], m[0, 1], m[0, 2]);
			FixedVector yRow = new FixedVector(m[1, 0], m[1, 1], m[1, 2]);

			int error = -xRow.Dot(yRow);		// Will be zero if there's no error

			// Scale the error term by half
			error /= 2;

			//	scale rows x and y by the error
			FixedVector xErr = xRow.Scale( error );
			FixedVector yErr = yRow.Scale( error );

			xRow = xRow.Add(yErr);		// Add the error corrections to the opposite row vector
			yRow = yRow.Add(xErr);

			xRow = xRow.Normalized();
			yRow = yRow.Normalized();

			FixedVector zRow = xRow.Cross( yRow );

			m[0, 0] = xRow.v[0];
			m[0, 1] = xRow.v[1];
			m[0, 2] = xRow.v[2];

			m[1, 0] = yRow.v[0];
			m[1, 1] = yRow.v[1];
			m[1, 2] = yRow.v[2];

			m[2, 0] = zRow.v[0];
			m[2, 1] = zRow.v[1];
			m[2, 2] = zRow.v[2];
		}

	}
}
