﻿
namespace DCMVisualizer
{
	public class Matrix
	{
		public float[,] m = new float[3, 3];

		public Matrix()
		{
		}

		public Matrix(Matrix from)
		{
			for (int i = 0; i < 3; i++) {
				for (int j = 0; j < 3; j++) {
					m[i, j] = from.m[i, j];
				}
			}
		}

		public Matrix(FixedMatrix from)
		{
			for (int i = 0; i < 3; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					m[i, j] = (float)from.m[i, j] / (float)(1 << FixedMatrix.Bits) ;
				}
			}
		}


		public Matrix Mul(Matrix m1)
		{
			Matrix r = new Matrix();
			for (int i = 0; i < 3; i++)
			{
				for (int j = 0; j < 3; j++)
				{
					r.m[i, j] = 0.0f;
					for (int k = 0; k < 3; k++)
					{
						r.m[i, j] += m[i, k] * m1.m[k, j];
					}
				}
			}
			return r;
		}

		public Vector Mul(Vector v1)
		{
			Vector r = new Vector();
			for (int i = 0; i < 3; i++)
			{
				r.v[i] = 0.0f;
				for (int j = 0; j < 3; j++)
				{
					r.v[i] += m[i, j] * v1.v[j];
				}
			}
			return r;
		}
	}
}
